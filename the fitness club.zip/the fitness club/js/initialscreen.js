function clickyes(){
    window.location.assign("http://167.88.242.62/loginscreen.html");
}
function clickno() {
    window.location.assign("http://167.88.242.62/registerscreen.html");
}